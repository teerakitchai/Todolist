from django.shortcuts import render
from django.http import JsonResponse

from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import serializers, status
# from rest_framework.serializers import Serializer
from .serializers import TodolistSerializer
from .models import Todolist

# GET Data


@api_view(['GET'])
def all_todolist(request):
    alltodolist = Todolist.objects.all()  # ดึงข้อมูลจาก model Todolist
    serializer = TodolistSerializer(alltodolist, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

# POST Data


@api_view(['POST'])
def post_todolist(request):
    if request.method == 'POST':
        serializer = TodolistSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)


# PUT data  (Update data)
@api_view(['PUT'])
def update_todolist(request, TID):
    todo = Todolist.objects.get(id=TID)
    if request.method == 'PUT':
        data = {}
        serializer = TodolistSerializer(todo, data=request.data)
        if serializer.is_valid():
            serializer.save()
            data['status'] = 'updated'
            return Response(data=data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)


@api_view(['DELETE'])
def delete_todolist(request, TID):
    todo = Todolist.objects.get(id=TID)
    if request.method == 'DELETE':
        delete = todo.delete()
        data = {}
        if delete:
            data['status'] = 'deleted'
            return Response(data=data, status=status.HTTP_200_OK)
        else:
            data['status'] = 'fail'
            return Response(data=data, status=status.HTTP_400_BAD_REQUEST)


data = [
    {
        "title": "คอมพิวเตอร์คืออะไร?",
        "subtitle": "คอมพิวเตอร์ คือ อุปกรณ์ที่ใช้สำหรับการคำนวณและทำงานอื่นๆ?",
        "image_url": "https://raw.githubusercontent.com/teerakitchai/BasicAPI/main/computer.jpg",
        "detail": "xxxx"
    },    {
        "title": "มาเขียนโปรแกรมกัน!",
        "subtitle": "บทความนี้จะแนะนำการเริ่มต้นเขียนโปรแกรม",
        "image_url": "https://raw.githubusercontent.com/teerakitchai/BasicAPI/main/coding.jpg",
        "detail": "yyyy"
    },    {
        "title": "Flutter คือ?",
        "subtitle": "Tools สำหรับออกแบบ UI ของ Google",
        "image_url": "https://raw.githubusercontent.com/teerakitchai/BasicAPI/main/mobileapp.jpg",
        "detail": "zzzz"
    }
]


def Home(request):
    return JsonResponse(data=data, safe=False, json_dumps_params={'ensure_ascii': False})
